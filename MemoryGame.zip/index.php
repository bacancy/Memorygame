<?php
    header('location:public/');
?>